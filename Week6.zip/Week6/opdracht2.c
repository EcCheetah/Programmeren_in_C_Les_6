#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <stdbool.h>

typedef struct _circle_ {
	int x;
	int y;
	int r; //for the radius
} circle;

bool do_circles_overlap(circle *circle_a, circle *circle_b);

int main() {
 
	//Make sure the circles overlap
	circle circle_a = {-2, -2, 7};
	circle circle_b = {3, 5, 4}; //Just some hardcoded values to make sure they hit each other

	bool overlap = do_circles_overlap(&circle_a, &circle_b);

	printf("Circle A with center @ (%d, %d) and radius %d and\n", circle_a.x, circle_a.y, circle_a.r);
	printf("Circle B with center @ (%d, %d) and radius %d ", circle_b.x, circle_b.y, circle_b.r);

	if (overlap) {
	  printf("a and b colide\n");
	}
	else if (!overlap) {
	  printf("a and b dont colide\n");
	}

	//Make sure the circles don't overlap
	circle circle_c = {2, 3, 4};
	circle circle_d = {8, 9, 2}; //Just some hardcoded values to make sure they don't hit each other

	overlap = do_circles_overlap(&circle_c, &circle_d);

	printf("Circle A with center @ (%d, %d) and radius %d and\n", circle_c.x, circle_c.y, circle_c.r);
	printf("Circle B with center @ (%d, %d) and radius %d ", circle_d.x, circle_d.y, circle_d.r);

	if (overlap) {
	  printf("a and b colide\n");
	}
	else if (!overlap) {
	  printf("a and b dont colide\n");
	}

	return 0;
}


bool do_circles_overlap(circle *circle_a, circle *circle_b) {
	bool overlap;

	double calcX = pow((circle_a->x - circle_b->x), 2);
	double calcY = pow((circle_a->y - circle_b->y), 2);
	double dist  = sqrt(calcX + calcY);

	double calcR = circle_a->r + circle_b->r;

	if (calcR > dist) {
	  overlap = true;
	} 
	else if (calcR < dist) {
	  overlap = false;
	}

	return overlap;
}

