#include <stdio.h>
#include <stdlib.h> //for malloc()

typedef struct _listitem {
	void *data;
	struct _listitem *next;
} Listitem;

typedef struct {
	Listitem *head, *tail;
} List;

void list_init(List *theList);
void list_add_to_tail(void *data, List *theList);
void list_print(List *theList);
void list_free(List *theList);

int main()
{
	char *a = "Amsterdam", *b = "Utrecht", *c = "Leeuwarden", *d = "Groningen";
	List myList;
	list_init(&myList);
	list_add_to_tail((void *)a, &myList);
	list_add_to_tail((void *)b, &myList);
	list_add_to_tail((void *)c, &myList);
	list_add_to_tail((void *)d, &myList);
	list_print(&myList);
	list_free(&myList);
	return 0;
}

void list_init(List *theList)
{
	theList->head = NULL;
	theList->tail = NULL;
}

void list_add_to_tail(void *data, List *theList)
{
	Listitem *city = malloc(sizeof(Listitem));

	city->data = data;
	city->next = 0;

	if (theList->head == 0) {
		theList->head = city;
		theList->tail = city;
	}
	
	else if (theList->head != 0) {
		theList->tail->next = city;
		theList->tail = city;
	}
}

void list_print(List *theList)
{
	if (theList->head != 0) {
		Listitem *current = theList->head;

		while(current) {
			char *value = current->data;
			printf("City name = %s\n", value);

			current = current->next;
		}
	}
	else if (theList->head == 0) {
		printf("ERROR: no items included in list\n");
	}
}

void list_free(List *theList)
{
	Listitem *current, *next;
	current = theList->head;
	while (current != NULL)
	{
		next = current->next;
		free(current);
		current = next;
	}
	list_init(theList);
}
